-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 17 Jun 2022 pada 13.27
-- Versi server: 10.4.14-MariaDB
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pos`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_barang2`
--

CREATE TABLE `tb_barang2` (
  `kode_barang` varchar(50) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `satuan` varchar(50) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `profit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_barang2`
--

INSERT INTO `tb_barang2` (`kode_barang`, `nama_barang`, `satuan`, `harga_beli`, `stok`, `harga_jual`, `profit`) VALUES
('   0905', '   Origami SIDU 12x12', 'Lusin', 5000, 70, 8000, 3000),
('   1105', '   Stapler Tembak', 'Lusin', 100000, 15, 160000, 60000),
('  0202', '  Lilin Mainan Kecil', 'PCS', 1250, 60, 2000, 750),
('  0702', '  Cat Air Guitar 120', 'PCS', 8333, 36, 15000, 6667),
('  1908', '  Penggaris Lentur 30cm', 'Lusin', 1875, 100, 3500, 1625),
('  3203', '  Gunting joyko/kenko besar', 'Lusin', 8083, 48, 15000, 6917),
(' 0104A', ' Faster C6', 'Lusin', 25833, 20, 35000, 9167),
(' 0201', ' Lilin Mainan Besar', 'Lusin', 3500, 50, 6000, 2500),
(' 0201A', ' Lilin Mainan Pth/Htm', 'Lusin', 4500, 36, 7000, 2500),
(' 0202A', ' Lilin Mainan Kecil', 'Lusin', 15000, 12, 22500, 7500),
(' 0405B', ' Lem Fox Botol 150g', 'Lusin', 9500, 48, 15000, 5500),
(' 0405C', ' Lem Fox Botol 500g', 'Lusin', 17000, 10, 27000, 10000),
(' 0407', ' Lem Stick 8gr', 'Lusin', 2000, 100, 3500, 1500),
(' 0407A', ' Lem Stick 15gr', 'Lusin', 3375, 100, 6000, 2625),
(' 0407B', ' Lem Stick 25gr', 'Lusin', 4750, 75, 8000, 3250),
(' 0408A', ' Lem Jaskol Bsr', 'Lusin', 1333, 50, 3000, 1667),
(' 0409', ' Lem UHU 7ml', 'Lusin', 5000, 48, 10000, 5000),
(' 0409A', ' Lem UHU 20ml', 'Lusin', 11000, 20, 18000, 7000),
(' 0409B', ' Lem UHU 35ml', 'Lusin', 14000, 20, 25000, 11000),
(' 0410', ' Lem Castol', 'Lusin', 5208, 20, 10000, 4792),
(' 0602', ' Clear Holder 40', 'Lusin', 19583, 36, 25000, 5417),
(' 0603', ' Clear Holder 60', 'Lusin', 25000, 36, 35000, 10000),
(' 0701', ' Cat Air Guitar 110', 'PCS', 8000, 36, 13000, 5000),
(' 0708', ' Kanvas 20x30', 'Lusin', 20000, 36, 30000, 10000),
(' 0902', ' Origami Asturo 15x15', 'Pack', 8000, 80, 12000, 4000),
(' 0907', ' Origami Bolak Balik', 'Lusin', 3000, 50, 5000, 2000),
(' 0908', ' Origami Motif Faber Castel', 'Lusin', 0, 15, 17000, 17000),
(' 1003', ' Pembolong Kertas Besar', 'Lusin', 36000, 8, 58000, 22000),
(' 1101', ' Stapler Joyko HD-10', 'PCS', 6083, 24, 10000, 3917),
(' 1107', ' Isi Staples Etona Bsr No.3', 'Lusin', 2850, 40, 7000, 4150),
(' 1112', ' Isi Staples Max HD-10', 'Lusin', 1875, 10, 4000, 2125),
(' 1112A', ' Isi Staples Max HD-10', 'Lusin', 37500, 10, 60000, 22500),
(' 1404', ' Nota 2ply bsr', 'Lusin', 5300, 30, 8000, 2700),
(' 1405', ' Nota 3ply Kcl', 'Lusin', 3900, 50, 6000, 2100),
(' 1406', ' Nota 3ply Bsr', 'Lusin', 7600, 30, 12000, 4400),
(' 1918', ' Penggaris Segitiga No.10', 'Lusin', 11250, 50, 20000, 8750),
(' 2003A', ' HVS Bola Dunia F4 70gr', 'Lusin', 207500, 60, 240000, 32500),
(' 2005A', ' HVS F4 75gr', 'Lusin', 202500, 50, 220000, 17500),
(' 2403', ' Drawing OPF', 'Lusin', 6250, 36, 10000, 3750),
(' 3003', ' Kertas Crepe Potongan', 'Lusin', 1750, 100, 3000, 1250),
(' 3003A', ' Kertas Crepe Potongan', 'Lusin', 17500, 20, 27000, 9500),
(' 3102', ' Isi Motex (Label Roll)', 'Lusin', 0, 36, 6500, 6500),
(' 3110', ' Tinta Stempel Pyramid', 'Lusin', 6000, 30, 10000, 4000),
(' 3201', ' Gunting joyko/kenko kecil', 'Lusin', 3750, 48, 7000, 3250),
(' 3202', ' Gunting joyko/kenko tanggung', 'Lusin', 5583, 48, 10000, 4417),
(' 3204', ' Gunting Gunindo OSS', 'Lusin', 3625, 48, 6000, 2375),
(' 3211', ' Gunting Kuku Biasa Kecil', 'Lusin', 2500, 35, 5000, 2500),
('0101', 'Kenko Easy Gel ', 'PCS', 1875, 210, 3000, 1125),
('0101A', 'Kenko Easy Gel', 'Lusin', 22500, 14, 33000, 10500),
('0102', 'Kenko K1', 'PCS', 2708, 199, 6000, 3292),
('0102A', 'Kenko K1', 'Lusin', 32500, 10, 65000, 32500),
('0103', 'Joyko JK100', 'PCS', 1388, 200, 3000, 1612),
('0103A', 'Joyko JK100', 'Lusin', 16666, 23, 30000, 13334),
('0104', 'Faster C6', 'PCS', 2152, 199, 3500, 1348),
('0105', 'Faster C600', 'PCS', 1212, 200, 3000, 1788),
('0105A', 'Faster C600', 'Lusin', 1234, 20, 30000, 28766),
('0106', 'Pen Snowman V5', 'PCS', 2083, 200, 3500, 1417),
('0106A', 'Pen Snowman V5', 'Lusin', 25000, 15, 38000, 13000),
('0107', 'Pen Boxy', 'PCS', 7083, 36, 10000, 2917),
('0108', 'Pen Balliner Pilot', 'PCS', 12083, 24, 18000, 5917),
('0109', 'Pen Joyko Spirit BP179', 'PCS', 2000, 36, 3500, 1500),
('0109A', 'Pen Joyko Spirit BP179', 'Lusin', 24000, 5, 35000, 11000),
('0110', 'Pen Kokoro', 'PCS', 4250, 36, 6500, 2250),
('0111', 'Pen Weiyada 4 Warna', 'PCS', 3625, 24, 6500, 2875),
('0112', 'Pen Joyko Focus BP338', 'PCS', 1000, 60, 1500, 500),
('0112A', 'Pen Joyko Focus BP338', 'Lusin', 12000, 10, 15000, 3000),
('0113', 'Pen Kenko Hi-Tech', 'PCS', 2833, 36, 5000, 2167),
('0113A', 'Pen Kenko Hi-Tech', 'Lusin', 34000, 10, 50000, 16000),
('0114', 'Pen Pilot Bptp', 'PCS', 1416, 200, 2500, 1084),
('0114A', 'Pen Pilot Bptp', 'Lusin', 17000, 12, 25000, 8000),
('0115', 'Pen Standard AE7', 'PCS', 1250, 240, 2000, 750),
('0115A', 'Pen Standard AE7', 'Lusin', 15000, 20, 20000, 5000),
('0116', 'Pen Diamond 8 Warna', 'Pack', 15000, 12, 25000, 10000),
('0117', 'Pen Faber Castell', 'PCS', 1875, 36, 5000, 3125),
('0118', 'Pen Apple Gel', 'PCS', 1000, 60, 2500, 1500),
('0118A', 'Pen Apple Gel', 'Lusin', 12000, 12, 25000, 13000),
('0119', 'Pen Tizo 1.0', 'PCS', 2833, 24, 6000, 3167),
('0120', 'Pen Snowman V2 ', 'PCS', 1458, 50, 2500, 1042),
('0120A', 'Pen Snowman V2', 'Lusin', 17500, 12, 25000, 7500),
('0121', 'Pen Snowman V1', 'PCS', 1458, 50, 2500, 1042),
('0121A', 'Pen Snowman V1', 'Lusin', 17500, 12, 25000, 7500),
('0122', 'Pen Korea ', 'PCS', 1583, 120, 3000, 1417),
('0123', 'Pen Gel Hapus', 'PCS', 2708, 36, 6000, 3292),
('0301', 'Loseleaf Kecil (A5) 50', 'Pack', 3500, 17, 6000, 2500),
('0301A', 'Loseleaf Kecil (A5) 100', 'Pack', 6000, 20, 10000, 4000),
('0302', 'Loseleaf Kecil (B5) 50', 'Pack', 5000, 20, 8000, 3000),
('0302A', 'Loseleaf Kecil (B5) 100', 'Pack', 9500, 20, 15000, 5500),
('0401', 'Lem Korea Epotec', 'PCS', 4800, 100, 7500, 2700),
('0401A', 'Lem Korea Epotec', 'Lusin', 54000, 100, 84000, 30000),
('0402', 'Lem OGlue (35ml)', 'PCS', 1458, 48, 2500, 1042),
('0402A', 'Lem OGlue (35ml)', 'Lusin', 17500, 12, 27500, 10000),
('0403', 'Lem OGlue (50ml)', 'PCS', 2000, 48, 4000, 2000),
('0403A', 'Lem OGlue (50ml)', 'Lusin', 24000, 12, 44000, 20000),
('0404', 'Lem Bakar Kecil', 'PCS', 812, 200, 2500, 1688),
('0404B', 'Lem Bakar Besar', 'PCS', 1, 100, 3500, 3499),
('0405', 'Lem Fox Kantong', 'PCS', 9500, 7, 15000, 5500),
('0405A', 'Lem Fox Stick', 'PCS', 8333, 36, 15000, 6667),
('0406', 'Lem Aibon', 'PCS', 9500, 10, 15000, 5500),
('0408', 'Lem Jaskol Kcl', 'PCS', 0, 50, 1500, 1500),
('0411', 'Lem Dextone', 'PCS', 0, 10, 20000, 20000),
('0412', 'Lem Povinal', 'PCS', 0, 20, 6500, 6500),
('0501', 'Isi Cutter Kecil', 'PCS', 2600, 48, 5000, 2400),
('0501A', 'Isi Cutter Kecil', 'Lusin', 29000, 10, 50000, 21000),
('0502', 'Isi Cutter Besar', 'PCS', 4666, 50, 8000, 3334),
('0502A', 'Isi Cutter Besar', 'Lusin', 56000, 10, 80000, 24000),
('0601', 'Clear Holder 20', 'PCS', 12500, 36, 20000, 7500),
('0703', 'Cat Acrylic Tube', 'PCS', 13000, 36, 20000, 7000),
('0704', 'Cat Acrylic Titi', 'PCS', 31666, 36, 48000, 16334),
('0705', 'Cat Acrylic LH6103', 'PCS', 0, 48, 35000, 35000),
('0706', 'Cat Air Titi', 'PCS', 20000, 48, 38000, 18000),
('0707', 'Cat Air Beiqi', 'PCS', 0, 36, 26500, 26500),
('0709', 'Kanvas 25x35', 'PCS', 0, 36, 35000, 35000),
('0710', 'Kanvas 30x40', 'PCS', 24000, 36, 40000, 16000),
('0711', 'Kanvas 40x60', 'PCS', 0, 24, 60000, 60000),
('0712', 'Kuas Set', 'PCS', 10000, 60, 15000, 5000),
('0801', 'Pianika Yamada', 'PCS', 75000, 12, 120000, 45000),
('0802', 'Pianika Marvel', 'PCS', 132500, 10, 190000, 57500),
('0803', 'Selang Pianica Yamada', 'PCS', 9166, 15, 15000, 5834),
('0804', 'Selang Pianica Yamaha', 'PCS', 0, 10, 20000, 20000),
('0901', 'Origami Asturo 12x12', 'Pack', 5000, 70, 8000, 3000),
('0903', 'Origami Asturo 16x16', 'Pack', 9000, 80, 14000, 5000),
('0904', 'Origami Asturo 20x20', 'Pack', 0, 50, 22000, 22000),
('0906', 'Origami SIDU 16x16', 'Pack', 8500, 50, 14000, 5500),
('1001', 'Pembolong Kertas Kecil', 'PCS', 9000, 15, 17000, 8000),
('1002', 'Pembolong Kertas Tanggung', 'PCS', 19000, 8, 32500, 13500),
('1102', 'Stapler Kenko HD-10', 'PCS', 6250, 24, 12000, 5750),
('1103', 'Stapler Max HD-10', 'PCS', 12083, 15, 18500, 6417),
('1104', 'Stapler HD-50', 'PCS', 15000, 12, 25000, 10000),
('1105', 'Stapler Mini HD10M', 'PCS', 0, 24, 8500, 8500),
('1106', 'Isi Staples Etona No.10', 'PCS', 0, 60, 3000, 3000),
('1108', 'Isi Staples Etona 23/10', 'PCS', 0, 10, 16000, 16000),
('1109', 'Isi Staples Etona 23/13', 'PCS', 0, 10, 21000, 21000),
('1110', 'Isi Staples Etona 23/15', 'PCS', 0, 10, 26000, 26000),
('1111', 'Isi Staples Tembak 13/8', 'PCS', 0, 20, 10000, 10000),
('1113', 'Isi Staples Max No.3', 'PCS', 0, 20, 8000, 8000),
('1201', 'Bk Gambar DODO A4', 'PCS', 2200, 100, 4000, 1800),
('1201A', 'Bk Gambar DODO A4', 'Pack', 22000, 20, 36000, 14000),
('1202', 'Bk Gambar DODO A3', 'PCS', 4600, 150, 8000, 3400),
('1202A', 'Bk Gambar DODO A3', 'Pack', 46000, 15, 72000, 26000),
('1203', 'Bk Gambar SIDU A4', 'PCS', 3200, 200, 5000, 1800),
('1203A', 'Bk Gambar SIDU A4', 'Pack', 16000, 30, 23000, 7000),
('1204', 'Bk Gambar SIDU A3', 'PCS', 0, 100, 8000, 8000),
('1204A', 'Bk Gambar SIDU A3', 'Pack', 0, 25, 37500, 37500),
('1205', 'Sketchbook A5', 'PCS', 8000, 15, 15000, 7000),
('1206', 'Sketchbook A4', 'PCS', 14500, 12, 28000, 13500),
('1207', 'Sketchbook A3', 'PCS', 25000, 15, 43000, 18000),
('1301', 'Bk Folio 100 PPL', 'PCS', 14700, 50, 20000, 5300),
('1301A', 'Bk Folio 100 PPL', 'Pack', 73500, 10, 95000, 21500),
('1302', 'Bk Folio 200 PPL', 'PCS', 27500, 50, 38000, 10500),
('1302A', 'Bk Folio 200 PPL', 'Pack', 82500, 15, 110000, 27500),
('1303', 'Bk Quarto 100 PPL', 'PCS', 8000, 100, 12000, 4000),
('1303A', 'Bk Quarto 100 PPL', 'Pack', 40000, 15, 55000, 15000),
('1304', 'Bk Quarto 200 PPL', 'PCS', 14500, 60, 20000, 5500),
('1304A', 'Bk Quarto 200 PPL', 'Pack', 43500, 12, 57000, 13500),
('1305', 'Bk Baster RIA 100', 'PCS', 9500, 20, 15000, 5500),
('1305A', 'Bk Baster RIA 100', 'Pack', 47500, 12, 70000, 22500),
('1306', 'Bk Expedisi PPL 100', 'PCS', 7800, 30, 12000, 4200),
('1306A', 'Bk Expedisi PPL 100', 'Pack', 39000, 12, 55000, 16000),
('1307', 'Bk Oktafo 100 PPL', 'PCS', 0, 30, 6000, 6000),
('1307A', 'Bk Oktafo 100 PPL', 'Pack', 0, 15, 25000, 25000),
('1308', 'Bk Oktafo 200 RIA', 'PCS', 0, 15, 12000, 12000),
('1401', 'Nota 1ply Kcl', 'PCS', 1900, 100, 3000, 1100),
('1401A', 'Nota 1ply Kcl', 'Pack', 19000, 12, 27000, 8000),
('1402', 'Nota 1ply Bsr', 'PCS', 0, 50, 5000, 5000),
('1403', 'Nota 2ply Kcl', 'PCS', 2750, 50, 5000, 2250),
('1403A', 'Nota 2ply Kcl', 'Pack', 27500, 15, 45000, 17500),
('1405A', 'Nota 3ply Kcl', 'Pack', 39000, 15, 54000, 15000),
('1407', 'Surat Jalan 3ply', 'PCS', 8200, 20, 12000, 3800),
('1407A', 'Surat Jalan 3ply', 'Pack', 82000, 15, 110000, 28000),
('1408', 'Faktur 3ply', 'PCS', 8200, 30, 12000, 3800),
('1408A', 'Faktur 3ply', 'Pack', 82000, 15, 110000, 28000),
('1409', 'Kwitansi Kcl', 'PCS', 1650, 30, 3000, 1350),
('1409A', 'Kwitansi Kcl', 'Pack', 16500, 15, 27000, 10500),
('1903', 'Penggaris Besi 30cm ', 'PCS', 4166, 48, 8000, 3834),
('1904', 'Penggaris Besi 40cm', 'PCS', 6000, 40, 12000, 6000),
('1905', 'Penggaris Besi 50cm', 'PCS', 7000, 40, 15000, 8000),
('1906', 'Penggaris Besi 60cm', 'PCS', 8000, 40, 18000, 10000),
('1907', 'Penggaris Lipat ', 'PCS', 1350, 50, 3000, 1650),
('1909', 'Penggaris Butterfly 20cm', 'PCS', 0, 250, 2000, 2000),
('1909A', 'Penggaris Butterfly 20cm', 'Lusin', 0, 50, 20000, 20000),
('1910', 'Penggaris Butterfly 30cm', 'PCS', 1666, 300, 3000, 1334),
('1910A', 'Penggaris Butterfly 30cm', 'Lusin', 20000, 50, 30000, 10000),
('1914', 'Penggaris Star Set 700', 'PCS', 8750, 50, 15000, 6250),
('1915', 'Busur 180', 'PCS', 1666, 100, 3000, 1334),
('1916', 'Busur 360', 'PCS', 0, 100, 5000, 5000),
('1917', 'Penggaris Segitiga No.8', 'PCS', 0, 30, 15000, 15000),
('1919', 'Penggaris Segitiga No.12', 'PCS', 14583, 50, 22000, 7417),
('2001', 'HVS Bola Dunia A4 70gr', 'Pack', 36500, 50, 43000, 6500),
('2001A', 'HVS Bola Dunia A4 70gr', 'Pack', 182500, 60, 210000, 27500),
('2002', 'HVS Bola Dunia A4 80gr', 'Pack', 41000, 100, 48000, 7000),
('2002A', 'HVS Bola Dunia A4 80gr', 'Pack', 205000, 60, 240000, 35000),
('2003', 'HVS Bola Dunia F4 70gr', 'Pack', 41500, 60, 48000, 6500),
('2004', 'HVS Bola Dunia F4 80gr', 'Pack', 46500, 60, 53000, 6500),
('2004A', 'HVS Bola Dunia F4 80gr', 'Pack', 232500, 60, 265000, 32500),
('2005', 'HVS F4 75gr', 'Pack', 40500, 50, 45000, 4500),
('2006', 'HVS A4 75gr', 'Pack', 0, 50, 45000, 45000),
('2006A', 'HVS A4 75gr', 'Pack', 0, 50, 220000, 220000),
('2007', 'HVS IK A4 70', 'Pack', 34000, 70, 41000, 7000),
('2007A', 'HVS IK A4 70', 'Pack', 170000, 50, 205000, 35000),
('2008', 'HVS IK F4 70', 'Pack', 0, 60, 46000, 46000),
('2008A', 'HVS IK F4 70', 'Pack', 0, 50, 230000, 230000),
('2101', 'Stabillo Joyko', 'PCS', 3100, 30, 5000, 1900),
('2102', 'Stabillo Boss', 'PCS', 5750, 50, 10000, 4250),
('2103', 'Stabillo GM 2 Warna', 'PCS', 2083, 36, 5000, 2917),
('2401', 'Drawing Pen', 'PCS', 6500, 30, 10000, 3500),
('2402', 'Drawing OPM', 'PCS', 6041, 36, 10000, 3959),
('3001', 'Karton Warna', 'PCS', 1458, 250, 3000, 1542),
('3001A', 'Karton Warna', 'Pack', 17500, 50, 27000, 9500),
('3002', 'Kertas Crepe', 'PCS', 1120, 250, 3000, 1880),
('3004', 'Asturo', 'PCS', 1050, 1000, 2500, 1450),
('3005', 'Kertas Samson', 'PCS', 1900, 100, 3000, 1100),
('3005A', 'Kertas Samson', 'Pack', 19000, 25, 27000, 8000),
('3006', 'Kertas Minyak', 'PCS', 760, 250, 2000, 1240),
('3007', 'Kertas Mas', 'PCS', 1000, 300, 2500, 1500),
('3008', 'Kertas Kopi', 'PCS', 960, 300, 2000, 1040),
('3008A', 'Kertas Kopi', 'Pack', 24000, 20, 45000, 21000),
('3009', 'Karton Duplex ', 'PCS', 6000, 100, 10000, 4000),
('3010', 'Kertas Kado Sansan Wawa Jumbo', 'PCS', 2500, 300, 5000, 2500),
('3011', 'Kertas Kado Sansan Wawa Kecil', 'PCS', 1250, 300, 2500, 1250),
('3012', 'Parcel Warna', 'PCS', 750, 200, 2000, 1250),
('3013', 'Parcel Polos', 'PCS', 800, 300, 2500, 1700),
('3014', 'Concorde 90gr', 'Pack', 0, 200, 13000, 13000),
('3015', 'Concorde 160gr', 'Pack', 0, 100, 14000, 14000),
('3016', 'Concorde 220gr', 'Pack', 0, 100, 14000, 14000),
('3101', 'Motex (Label Roll)', 'PCS', 40000, 10, 75000, 35000),
('3102A', 'Isi Motex (Label Roll)', 'Lusin', 0, 10, 58500, 58500),
('3103', 'Tinta Motex ', 'PCS', 0, 10, 10000, 10000),
('3104', 'Kertas Strook Bsr', 'PCS', 3900, 30, 6500, 2600),
('3104A', 'Kertas Strook Bsr', 'Pack', 39000, 10, 58500, 19500),
('3105', 'Kertas Strook Kcl', 'PCS', 0, 30, 3500, 3500),
('3105A', 'Kertas Strook Kcl', 'Pack', 0, 10, 31500, 31500),
('3106', 'Kertas EDC', 'PCS', 0, 50, 7000, 7000),
('3106A', 'Kertas EDC', 'Pack', 0, 10, 63000, 63000),
('3107', 'Stempel Lunas', 'PCS', 0, 20, 15000, 15000),
('3108', 'Stempel Nomor', 'PCS', 0, 20, 12000, 12000),
('3109', 'Stempel Tanggal', 'PCS', 0, 20, 0, 0),
('3111', 'Tinta Stempel Tetes', 'PCS', 0, 20, 17000, 17000),
('3112', 'Bak Stempel Hero Bsr', 'PCS', 0, 20, 16000, 16000),
('3113', 'Bak Stempel Hero Kcl', 'PCS', 0, 20, 14000, 14000),
('3114', 'Bak Stempel Jk Bsr', 'PCS', 0, 20, 12000, 12000),
('3115', 'Bak Stempel Jk Kcl', 'PCS', 0, 20, 10000, 10000),
('3205', 'Gunting Gunindo OMM', 'PCS', 4166, 48, 8000, 3834),
('3206', 'Gunting Gunindo OLL', 'PCS', 5000, 48, 9000, 4000),
('3207', 'Gunting TK SO-03', 'PCS', 3125, 40, 7000, 3875),
('3208', 'Gunting Trend ', 'PCS', 0, 60, 3500, 3500),
('3209', 'Gunting Kuku Mas Kecil', 'PCS', 11250, 24, 18000, 6750),
('3210', 'Gunting Kuku Mas Besar', 'PCS', 20000, 25, 30000, 10000),
('3212', 'Gunting Kuku Biasa Besar', 'PCS', 7291, 36, 13000, 5709),
('3213', 'Gunting Lipat Kecil', 'PCS', 2083, 36, 5000, 2917);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_customer2`
--

CREATE TABLE `tb_customer2` (
  `id_customer` varchar(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` text NOT NULL,
  `telpon` varchar(15) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_customer2`
--

INSERT INTO `tb_customer2` (`id_customer`, `nama`, `alamat`, `telpon`, `email`) VALUES
('P001', 'Umum', '', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pembelian2`
--

CREATE TABLE `tb_pembelian2` (
  `id` int(9) NOT NULL,
  `kode_pembelian` varchar(50) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_pembelian2`
--

INSERT INTO `tb_pembelian2` (`id`, `kode_pembelian`, `kode_barang`, `jumlah`, `harga`, `total`, `tanggal`) VALUES
(21, 'PB-22322', '0101', 2, 1875, 3750, '2022-03-26'),
(22, 'PB-22322', '0101a', 10, 22500, 225000, '2022-03-26'),
(23, 'PB-99227', '0101', 12, 1875, 22500, '2022-04-12'),
(24, 'PB-3232', '0101', 1, 1875, 1875, '2022-04-12'),
(25, 'PB-3230202', '0101', 2, 1875, 3750, '2022-05-31');

--
-- Trigger `tb_pembelian2`
--
DELIMITER $$
CREATE TRIGGER `beli_barang` AFTER INSERT ON `tb_pembelian2` FOR EACH ROW BEGIN
 INSERT INTO tb_barang2 SET
 kode_barang = NEW.kode_barang, stok=New.jumlah
 ON DUPLICATE KEY UPDATE stok=stok+New.jumlah;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan2`
--

CREATE TABLE `tb_penjualan2` (
  `id` int(11) NOT NULL,
  `kode_penjualan` varchar(50) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tanggal_penjualan` date NOT NULL,
  `id_customer` varchar(10) NOT NULL,
  `kasir` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan2`
--

INSERT INTO `tb_penjualan2` (`id`, `kode_penjualan`, `kode_barang`, `jumlah`, `total`, `tanggal_penjualan`, `id_customer`, `kasir`) VALUES
(174, 'PJ-2006303', '0103A', 1, 30000, '2022-03-26', '', ''),
(175, 'PJ-2006303', '0102a', 2, 130000, '2022-03-26', '', ''),
(176, 'PJ-3303', '0101', 1, 3000, '2022-03-26', '', ''),
(177, 'PJ-32042', '0101', 1, 3000, '2022-03-26', '', ''),
(178, 'PJ-32042', '0101a', 2, 66000, '2022-03-26', '', ''),
(179, 'PJ-32042', '0102', 1, 6000, '2022-03-26', '', ''),
(180, 'PJ-6332325', '0101a', 2, 66000, '2022-03-26', 'P001', 'Resi'),
(181, 'PJ-6332325', '0104', 1, 3500, '2022-03-26', 'P001', 'Resi'),
(182, 'PJ-6332325', '0301', 3, 18000, '2022-03-26', 'P001', 'Resi'),
(183, 'PJ-2350783', '0101a', 3, 99000, '2022-04-13', '', ''),
(184, 'PJ-68403632', '0101', 2, 6000, '2022-04-15', '', '');

--
-- Trigger `tb_penjualan2`
--
DELIMITER $$
CREATE TRIGGER `jual_barang` AFTER INSERT ON `tb_penjualan2` FOR EACH ROW BEGIN
 UPDATE tb_barang2
 SET stok= stok- NEW.jumlah
 WHERE
 kode_barang = NEW.kode_barang;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_penjualan_tmp2`
--

CREATE TABLE `tb_penjualan_tmp2` (
  `id_tmp` int(11) NOT NULL,
  `kode_penjualan` varchar(50) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembali` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_penjualan_tmp2`
--

INSERT INTO `tb_penjualan_tmp2` (`id_tmp`, `kode_penjualan`, `bayar`, `kembali`) VALUES
(38, 'PJ-3034322', 20000, 3000),
(39, 'PJ-22897233', 50000, 2000),
(45, 'PJ-6332325', 100000, 12500);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_retur`
--

CREATE TABLE `tb_retur` (
  `id` int(11) NOT NULL,
  `kode_retur` varchar(50) NOT NULL,
  `kode_barang` varchar(50) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `tgl_retur` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_retur`
--

INSERT INTO `tb_retur` (`id`, `kode_retur`, `kode_barang`, `jumlah`, `harga`, `total`, `tgl_retur`) VALUES
(13, 'RT-5323233', '1234567891', 1, 2000, 2000, '2019-05-04'),
(17, 'RT-27333220', '0101', 3, 1875, 5625, '2022-04-13'),
(18, 'RT-0202822', '0101a', 1, 22500, 22500, '2022-04-13');

--
-- Trigger `tb_retur`
--
DELIMITER $$
CREATE TRIGGER `retur` AFTER INSERT ON `tb_retur` FOR EACH ROW BEGIN
 UPDATE tb_barang2
 SET stok= stok- NEW.jumlah
 WHERE
 kode_barang = NEW.kode_barang;
 END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_user`
--

CREATE TABLE `tb_user` (
  `id` int(11) NOT NULL,
  `user_id` varchar(12) COLLATE latin1_general_ci NOT NULL,
  `nama` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pass` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `level` varchar(25) COLLATE latin1_general_ci NOT NULL,
  `status` varchar(30) COLLATE latin1_general_ci NOT NULL,
  `foto` varchar(100) COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `tb_user`
--

INSERT INTO `tb_user` (`id`, `user_id`, `nama`, `email`, `pass`, `level`, `status`, `foto`) VALUES
(7, 'kasir', 'Resi', 'crusgeming11@gmail.com', 'kasir', 'admin', 'Aktif', 'aesthetic-anime-02.jpg'),
(6, 'admin', 'Anisah', 'anisahfitrin86@gmail.com', 'admin', 'admin', 'Aktif', 'WhatsApp Image 2021-08-06 at 00.31.48.jpeg');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_barang2`
--
ALTER TABLE `tb_barang2`
  ADD PRIMARY KEY (`kode_barang`);

--
-- Indeks untuk tabel `tb_customer2`
--
ALTER TABLE `tb_customer2`
  ADD PRIMARY KEY (`id_customer`);

--
-- Indeks untuk tabel `tb_pembelian2`
--
ALTER TABLE `tb_pembelian2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_penjualan2`
--
ALTER TABLE `tb_penjualan2`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_penjualan_tmp2`
--
ALTER TABLE `tb_penjualan_tmp2`
  ADD PRIMARY KEY (`id_tmp`);

--
-- Indeks untuk tabel `tb_retur`
--
ALTER TABLE `tb_retur`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_pembelian2`
--
ALTER TABLE `tb_pembelian2`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT untuk tabel `tb_penjualan2`
--
ALTER TABLE `tb_penjualan2`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=185;

--
-- AUTO_INCREMENT untuk tabel `tb_penjualan_tmp2`
--
ALTER TABLE `tb_penjualan_tmp2`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT untuk tabel `tb_retur`
--
ALTER TABLE `tb_retur`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `tb_user`
--
ALTER TABLE `tb_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
